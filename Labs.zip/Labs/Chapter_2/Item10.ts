const s: String = "primitive";
const n: Number = 12;
const b: boolean = true;

console.log(s);
console.log(n);
console.log(b);