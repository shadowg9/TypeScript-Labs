function add(a: number, b: number) { return a + b; }
function sub(a: number, b: number) { return a - b; }
function mul(a: number, b: number) { return a * b; }
function div(a: number, b: number) { return a / b; }

console.log(add(5,5));
console.log(sub(5,5));
console.log(mul(5,5));
console.log(div(5,5));