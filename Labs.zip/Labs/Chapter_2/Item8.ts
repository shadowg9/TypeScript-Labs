class Cylinder {
    radius=1;
    height=1;
   }
   function calculateVolume(shape: unknown) {
    if (shape instanceof Cylinder) {
    shape 
    shape.radius 
    }
   }

   const v = typeof Cylinder; 
   type T = typeof Cylinder; 

declare let fn: T;
const c = new fn(); 

type C = InstanceType<typeof Cylinder>; 

