


function parseTaggedText(lines: string[]): string[][] {
    let currPara: readonly string[] = [];
    const paragraphs: string[][] = [];
    const addParagraph = () => {
        if (currPara.length) {

            paragraphs.push(
            );
            currPara = []; 
            
        }
    };
    for (const line of lines) {
        if (!line) {
            addParagraph();
        } else {
            currPara.concat([line]);
            
        }
    }
    addParagraph();
    return paragraphs;
}