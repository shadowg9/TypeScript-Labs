interface Room {
    numDoors: number;
    ceilingHeightFt: number;
}

const obj = {
    numDoors: 2,
    ceilingHeightFt: 12,
    elephant: 'present',
};

const r: Room = obj;

console.log(r);