function parseCSV(input: string): { [columnName: string]: string }[] {
    const lines = input.split('\n');
    const [headerLine, ...rows] = lines;
    const headers = headerLine.split(',');
    return rows.map(rowStr => {
        const row: { [columnName: string]: string } = {};
        rowStr.split(',').forEach((cell, i) => {
            row[headers[i]] = cell;
        });
        return row;
    });
}

interface ProductRow {
    productId: string;
    name: string;
    price: string;
}
declare let csvData: string;
const products = parseCSV(csvData) as unknown as ProductRow[];

function safeParseCSV(
    input: string
): { [columnName: string]: string | undefined }[] {
    return parseCSV(input);
}

const rows = parseCSV(csvData);
const prices: { [produt: string]: number } = {};
for (const row of rows) {
    prices[row.productId] = Number(row.price);
}


interface Row1 { [column: string]: number } // Too broad
interface Row2 { a: number; b?: number; c?: number; d?: number } // Better
type Row3 =
    | { a: number; }
    | { a: number; b: number; }
    | { a: number; b: number; c: number; }
    | { a: number; b: number; c: number; d: number };


type Vec3D = { [k in 'x' | 'y' | 'z']: number };

type ABC = { [k in 'a' | 'b' | 'c']: k extends 'b' ? string : number };
