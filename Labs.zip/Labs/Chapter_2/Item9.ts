interface Person { name: string };
const alice: Person = { name: 'Alice' }; 
const bob = { name: 'Bob' } as Person; 

const people = ['alice', 'bob', 'jan'].map(
    (name): Person => ({name})
   );

