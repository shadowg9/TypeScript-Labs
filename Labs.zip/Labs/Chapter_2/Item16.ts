const xs = [1, 2, 3];
const x0 = xs[0]; 
const x1 = xs['1']; 
function get<T>(array: T[], k: string): T {
    return array[k];
    
}

const keys = Object.keys(xs); 
for (const key in xs) {
    key; 
    const x = xs[key]; 
}

for (const x of xs) {
    x; 
}

xs.forEach((x, i) => {
    i; 
    x; 
});

for (let i = 0; i < xs.length; i++) {
    const x = xs[i];
    if (x < 0) break;
}

function checkedAccess<T>(xs: ArrayLike<T>, i: number): T {
    if (i < xs.length) {
        return xs[i];
    }
    throw new Error(`Attempt to access ${i} which is past end of array.`)
}

const tupleLike: ArrayLike<string> = {
    '0': 'A',
    '1': 'B',
    length: 12,
};