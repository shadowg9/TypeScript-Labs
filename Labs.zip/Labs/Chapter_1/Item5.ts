interface Person {
    firstName: string;
    last: string;
   }
   const formatName = (p: Person) => `${p.firstName} ${p.last}`;
   const formatNameAny = (p: any) => `${p.first} ${p.last}`;
   
   interface ComponentProps {
    onSelectItem: (item: any) => void;
   }
   
   function renderSelector(props: ComponentProps) { /* ... */ }
let selectedId: number = 0;
function handleSelectItem(item: any) {
 selectedId = item.id;
}
renderSelector({onSelectItem: handleSelectItem});