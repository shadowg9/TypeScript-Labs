const id = "12-34-56";
fetchProduct(id);
{
 const id = 123456; 
 fetchProductBySerialNumber(id); 
}
