const person = {
    name: 'Sojourner Truth',
    born: {
        where: 'Swartekill, NY',
        when: 'c.1797',
    },
    died: {
        where: 'Battle Creek, MI',
        when: 'Nov. 26, 1883'
    }
};


function square(nums: number[]) {
    return nums.map(x => x * x);
   }
   const squares = square([1, 2, 3, 4]); 
   
const axis1: string = 'x'; 
const axis2 = 'y'; 

interface Product {
    id: number;
    name: string;
    price: number;
   }



   function logProduct(product: Product) {
    const {id, name, price} = product;
    console.log(id, name, price);
   }
   
   const cache: {[ticker: string]: number} = {};
function getQuote(ticker: string) {
 if (ticker in cache) {
 return cache[ticker];
 }
 return fetch(`https://quotes.example.com/?q=${ticker}`)
 .then(response => response.json())
 .then(quote => {
 cache[ticker] = quote;
 return quote;
 });
}

interface Vector2D { x: number; y: number; }
function add(a: Vector2D, b: Vector2D) {
 return { x: a.x + b.x, y: a.y + b.y };
}

