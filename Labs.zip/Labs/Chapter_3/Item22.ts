const el = document.getElementById('foo'); 
if (el) {
 el 
 el.innerHTML = 'Party Time'.blink();
} else {
 el 
 alert('No element #foo');
}

interface UploadEvent { type: 'upload'; filename: string; contents: string }
interface DownloadEvent { type: 'download'; filename: string; }
type AppEvent = UploadEvent | DownloadEvent;
function handleEvent(e: AppEvent) {
 switch (e.type) {
 case 'download':
 e // Type is DownloadEvent
 break;
 case 'upload':
 e; // Type is UploadEvent
 break;
 }
}

const jackson5 = ['Jackie', 'Tito', 'Jermaine', 'Marlon', 'Michael'];
const members = ['Janet', 'Michael'].map(
 who => jackson5.find(n => n === who)
); 


