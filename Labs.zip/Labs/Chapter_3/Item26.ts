function panTo(where: readonly [number, number]) { /* ... */ }
const loc = [10, 20] as const;
panTo(loc); 




function callWithRandomNumbers(fn: (n1: number, n2: number) => void) {
    fn(Math.random(), Math.random());
   }
   callWithRandomNumbers((a, b) => {
    a; 
    b; 
    console.log(a + b);
   });